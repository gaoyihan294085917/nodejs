//项目入口文件
const express = require('express');
const cookieParser = require('cookie-parser');
const app = express();
const path = require('path');
//引入路由中间件
const indexRouter = require('./routes/indexRoutes')
const bannerRuter = require('./routes/bannerRoutes')
const userRuter = require('./routes/userRuter');
const usersRuter = require('./routes/usersRoutes')
const filmsRuter = require('./routes/filmsRuter')
const cinemaRuter = require('./routes/cinemaRoute')
//设置静态文件托管
app.use(express.static(path.resolve(__dirname,'./public')))


//使用中间件,记得要放到路由文件前使用,不然无法拿到对应的cookie body
//cookie中间件
app.use(cookieParser());
//body中间件 extended:true表示使用第三方qs模块
app.use(express.json());
app.use(express.urlencoded({extended:true}));
//设置模板文件路径,以及使用什么模板引擎  view engine是固定格式不要写错
app.set('views',path.resolve(__dirname,'views'));
app.set('view engine','ejs')

//解决跨域问题中间件,设置响应头
app.use(function(req,res,next){
  res.set('Access-Control-Allow-Origin','*');
  res.set('Access-Control-Allow-Headers','Content-Type');
  next();
})


//路由文件使用,把路由文件抽取到routes文件里
app.use('/',indexRouter);
app.use('/banner',bannerRuter);
app.use('/user',userRuter);
app.use('/users',usersRuter);
app.use('/films',filmsRuter);
app.use('/cinema',cinemaRuter)
app.listen(80);
