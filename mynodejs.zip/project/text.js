const express = require('express');
const multer = require('multer');
const fs = require('fs');
const path = require('path');

const app = express();

const upload = multer({
    dest:'d:/tmp',
})

app.post('/upload',upload.single('avatar'),(req,res)=>{
    //新文件名
    let newFileName = new Date().getTime() + '_' + req.file.originalname;
    //新文件完整路径
    let newFilePath = path.resolve(__dirname,'./public/uploads/' + newFileName);

    try {
        //读原文件路径
        let data = fs.readFileSync(req.file.path);
        //写入新文件
        fs.writeFileSync(newFilePath,data);
        //删除原文件
        fs.unlink(req.file.path);
        res.json({
            code : 1,
            msg : 'ok'
        })
    } catch (error) {
        res.json({
            code : -1,
            msg : error.message
        })
    }
    


})

app.listen(3000);