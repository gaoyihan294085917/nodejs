const db = require('../config/db')

const schema = new db.Schema({
    name : String,
    imgUrl : String,
    start : String,//上映时间
    country : String,//地区
    text : String,//简介
    actor : String,//主演
    grade : Number,//评分
    type : String//电影类型
});


module.exports = db.model('film',schema)