//引入db模块
const db = require('../config/db');
//定义schama对象,在这个对象里配置用户表里的字段和数据结构
const schema = new db.Schema({
    //用户名字段
    userName : {
        type : String,
        require : true//表示字段必填
    },
    //密码字段
    passWord : {
        type : String,
        require : true//表示字段必填
    },
    //用户昵称字段
    nickName : {
        type : String,
        default : '普通用户'//默认值
    },
    //是否是管理员
    isAdmin : {
        type : Number,//枚举型,0代表不是管理员,1代表是管理员
        default : 0//默认值是0
    }
})
//基于schema通过db.model('表名的单数形式',schema)方法暴露出去
module.exports = db.model('user',schema);