//用户验证中间件函数

module.exports = function(req,res,next){

    console.log(req.query,"111")
    //得到nickName
    let nickName = req.cookies.nickName;
    if (nickName) {
        //存在可以访问其他页面
        next();
    } else {
        //不存在,就重定向到登录页
        res.redirect('/login.html')
    }
}
