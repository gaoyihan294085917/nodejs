//页面渲染的路由
const express = require('express');
//基于express的Router函数
const router = express.Router();
//引入自己写的登录验证中间件
const userCheck = require('../middlewares/userCheck');



//首页 http://localhost:3000/
router.get('/',userCheck,(req,res) =>{
    // //获取用户登陆的用户名
    //let nickName = req.cookies.nickName;
    //let isAdmin = req.cookies.isAdmin ? true : false
    res.render('index',{
        nickName:req.cookies.nickName,
        isAdmin :parseInt(req.cookies.isAdmin)
    });
    // if (nickName) {//判断是否登录
    //     //渲染页面的方法 index表示他会在views文件里面找一个叫index.ejs的文件
    //     //存在就去想去的页面,首页
    //     res.render('index',{
    //         nickName : nickName,
    //         isAdmin : isAdmin
    //     })
    // } else {//如果不存在
    //     //去登录页
    //     //res.render('login') 这种方法url地址是不会改变的,要用重定向
    //     //res.redirect('http://localhost:3000/login.html')res.redirect(url地址) 同一个域名地址可以省略前缀
    //     res.redirect('login.html')
    // }

})
//banner页面
router.get('/banner.html',userCheck,(req,res) =>{
    // //获取用户登陆的用户名
    //let nickName = req.cookies.nickName;
    //let isAdmin = req.cookies.isAdmin ? true : false
    res.render('banner',{
        nickName:req.cookies.nickName,
        isAdmin :parseInt(req.cookies.isAdmin)
    });
    // if (nickName) {//判断是否登录
    //     //渲染页面的方法 index表示他会在views文件里面找一个叫banner.ejs的文件
    //     //存在就去想去的页面,首页
    //     res.render('banner',{
    //         nickName : nickName,
    //         isAdmin : isAdmin
    //     })
    // } else {//如果不存在
    //     //去登录页
    //     //res.render('login') 这种方法url地址是不会改变的,要用重定向
    //     //res.redirect('http://localhost:3000/login.html')res.redirect(url地址) 同一个域名地址可以省略前缀
    //     res.redirect('login.html')
    // }
})
//登录页面
router.get('/login.html',(req,res) =>{
    res.render('login')
})





//用户管理页面
router.get('/users.html',userCheck,(req,res)=>{
    res.render('users',{
        nickName:req.cookies.nickName,
        isAdmin :parseInt(req.cookies.isAdmin)
    });
})
//影片管理页面
router.get('/films.html',userCheck,(req,res)=>{
    res.render('films',{
        nickName:req.cookies.nickName,
        isAdmin :parseInt(req.cookies.isAdmin)
    });
})
//影院管理页面
router.get('/cinema.html',userCheck,(req,res)=>{
    res.render('cinema',{
        nickName:req.cookies.nickName,
        isAdmin :parseInt(req.cookies.isAdmin)
    });
})
module.exports = router;
