
//提供给前端 ajax 调用的接口地址,url
//页面渲染的路由
const express = require('express');
const BannerModel = require('../models/bannerModel')
//文件上传
const multer = require('multer');
const upload = multer({
    dest : 'd:/tmp'
})


const path = require('path');
const fs = require('fs');
const async = require('async');

//基于express的Router函数
const router = express.Router();

//添加banner http://localhost:3000/banner/add
router.post('/add', upload.single('bannerImg'),(req,res) =>{
    //1.操作文件,把文件放在public下
    let newFileName = new Date().getTime() + '_' + req.file.originalname;
    let newFilePath = path.resolve(__dirname,'../public/uploads/banners/',newFileName);
    //console.log(newFilePath)
    //2.文件移动操作
    try {
        //文件的读写删除
        let data = fs.readFileSync(req.file.path);
        
        fs.writeFileSync(newFilePath,data);
        
        fs.unlinkSync(req.file.path)
        
        //将文件名字 + banner 图的名字写入到数据库

        let banner = new BannerModel({
            name : req.body.bannerName,
            imgUrl : 'http://localhost:3000/uploads/banners/' + newFileName
        });
        
        banner.save().then(()=>{
            res.json({
                code : 0,
                msg : 'ok'
            })
            console.log(111)
        }).catch(error =>{
            res.json({
                code : -1,
                msg : error.message
            })
        })
    } catch (error) {
        res.json({
            code : -1,
            msg : error.message
        })
    }





    //获取前端传递过来的参数
    // var banner = new BannerModel({
    //     name : req.body.bannerName,
    //     imgUrl:req.body.bannerUrl
    // })
    // console.log(banner.imgUrl);
    // banner.save(function(err){
    //     if(err){
    //         res.json({
    //             code : -1,
    //             msg : err.message
    //         })
    //     }else{
    //         res.json({
    //             code : 0,
    //             msg : 'ok'
    //         })
    //     }
    // })
    
})

//搜索和查询banner http://localhost:3000/banner/search
router.get('/search',(req,res)=>{
    //解决跨域问题,可以做成一个中间件使用
    //res.set('Access-Control-Allow-Origin','*')


    let pageNum = parseInt(req.query.pageNum) || 1;//当前页数
    let pageSize = parseInt(req.query.pageSize) || 2;//每页显示的条数
   // let totalSize = 0;
    async.parallel([
        function(cb){
            BannerModel.find().count().then(num =>{
                //totalSize = num; 
                cb(null,num);
            }).catch(err =>{
                cb(err);
            }) 
        },
        function(cb){
            BannerModel.find().skip(pageNum * pageSize - pageSize).limit(pageSize)
            .then(data =>{
                cb(null,data);
            }).catch(err =>{
                cb(err);
            })
        }
    ],function(err,result){
        //接收过来是一个数组,第一项是num,第二项是返回来的data
        if (err) {
            res.json({
                code:-1,
                msg:err.message
            })
        } else {
            res.json({
                code:0,
                msg:'ok',
                data:result[1],
                //总页数
                totalPage:Math.ceil(result[0] / pageSize)
            })
        }
    })







    // BannerModel
    //     .find()
    //     .skip(pageNum * pageSize - pageSize)
    //     .limit(pageSize)
    //     .then(result =>{
    //         console.log(result)
    //         res.json({
    //             code:0,
    //             msg:'ok',
    //             data:result
    //         })
    //     })
    //     .catch(err =>{
    //         console.log(err.message);
    //         res.json({
    //             code:-1,
    //             msg:err.message
    //         })
    //     })










    // BannerModel.find(function(err,result){
    //     if (err) {
    //         console.log('查询失败');
    //         res.json({
    //             code:-1,
    //             msg:err.message
    //         })
    //     } else {
    //         console.log('查询成功');
    //         res.json({
    //             code:0,
    //             msg:'ok',
    //             data:result
    //         }) 
    //     }
    // })
})

//删除 http://localhost:3000/banner/delete

router.post('/delete',(req,res)=>{
    //通过id删除,得到要删除的id字段,前端传过来,post请求,前端传id变量
    let id = req.body.id;

    //操作BannerModel 删除方法
    BannerModel.findOneAndDelete({
        _id : id
    }).then((data)=>{
        if (data) {
            res.json({
                code : 0,
                msg : 'ok'
            }) 
        } else {
            return Promise.reject(new Error('未找到相关数据'))
            // res.json({
            //     code :-1,
            //     msg :'为找到相关数据'
            // })
        }
        
    }).catch(error =>{
        res.json({
            code : -1,
            msg : error.message
        })
    })
})

router.post('/searchOne',(req,res)=>{
    //通过id删除,得到要删除的id字段,前端传过来,post请求,前端传id变量
    let id = req.body.id;

    //操作BannerModel 删除方法
    BannerModel.findById({
        _id : id
    }).then((data)=>{
        //console.log(data)
        if (data) {
            res.json({
                code : 0,
                msg : 'ok',
                data:data
            }) 
        } else {
            return Promise.reject(new Error('未找到相关数据'))
            // res.json({
            //     code :-1,
            //     msg :'为找到相关数据'
            // })
        }
        
    }).catch(error =>{
        res.json({
            code : -1,
            msg : error.message
        })
    })
})


router.post('/updateById',upload.single('bannerImg'),(req,res)=>{
    console.log(req.file)
    //1.操作文件,把文件放在public下
    //console.log(req.body.bannerName)
    let newFileName = new Date().getTime() + '_' + req.file.originalname;
    let newFilePath = path.resolve(__dirname,'../public/uploads/banners/',newFileName);
    //console.log(newFilePath)
    //2.文件移动操作
    try {
        //文件的读写删除
        let data = fs.readFileSync(req.file.path);
        
        fs.writeFileSync(newFilePath,data);
        
        fs.unlinkSync(req.file.path)
        
        //将文件名字 + banner 图的名字写入到数据库
        BannerModel.updateOne({_id : req.body.id},{name:req.body.bannerName,imgUrl:'http://localhost:3000/uploads/banners/' + newFileName},function(error,docs){
            if (error) {
                console.log(req.body.id)
                res.json({
                    code : -1,
                    msg : error.message
                })
            } else {
                res.json({
                    code : 0,
                    msg : 'ok'
                })
                //console.log(docs)
            }
        })
    } catch (error) {
        res.json({
            code : -1,
            msg : error.message
        })
    }
})
module.exports = router;
