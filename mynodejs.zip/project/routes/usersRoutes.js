
//提供给前端 ajax 调用的接口地址,url
//页面渲染的路由
const express = require('express');
const UsersModel = require('../models/userModel')
//文件上传
const multer = require('multer');
const upload = multer({
    dest : 'd:/tmp'
})


//const path = require('path');
const fs = require('fs');
const async = require('async');

//基于express的Router函数
const router = express.Router();

//添加users http://localhost:3000/users/add
router.post('/add', upload.single('usersImg'),(req,res) =>{
    //1.操作文件,把文件放在public下
    //let newFileName = new Date().getTime() + '_' + req.file.originalname;
    //let newFilePath = path.resolve(__dirname,'../public/uploads/users/',newFileName);
    //console.log(newFilePath)
    //2.文件移动操作
    try {
        //文件的读写删除
        //let data = fs.readFileSync(req.file.path);
        
        //fs.writeFileSync(newFilePath,data);
        
        //fs.unlinkSync(req.file.path)
        
        //将文件名字 + users 图的名字写入到数据库

        let users = new UsersModel({
            userName : req.body.userName,
            isAdmin : req.body.isAdmin,
            nickName : req.body.nickName,
            passWord : req.body.passWord,
        });
        
        users.save().then(()=>{
            res.json({
                code : 0,
                msg : 'ok'
            })
            console.log(111)
        }).catch(error =>{
            res.json({
                code : -1,
                msg : error.message
            })
        })
    } catch (error) {
        res.json({
            code : -1,
            msg : error.message
        })
    }




})

//搜索和查询users http://localhost:3000/users/search
router.get('/search',(req,res)=>{
    let pageNum = parseInt(req.query.pageNum) || 1;//当前页数
    let pageSize = parseInt(req.query.pageSize) || 2;//每页显示的条数
   // let totalSize = 0;
    async.parallel([
        function(cb){
            UsersModel.find().count().then(num =>{
                //totalSize = num; 
                cb(null,num);
            }).catch(err =>{
                cb(err);
            }) 
        },
        function(cb){
            UsersModel.find().skip(pageNum * pageSize - pageSize).limit(pageSize)
            .then(data =>{
                cb(null,data);
            }).catch(err =>{
                cb(err);
            })
        }
    ],function(err,result){
        //接收过来是一个数组,第一项是num,第二项是返回来的data
        if (err) {
            res.json({
                code:-1,
                msg:err.message
            })
        } else {
            res.json({
                code:0,
                msg:'ok',
                data:result[1],
                //总页数
                totalPage:Math.ceil(result[0] / pageSize)
            })
        }
    })

})

//删除 http://localhost:3000/users/delete

router.post('/delete',(req,res)=>{
    //通过id删除,得到要删除的id字段,前端传过来,post请求,前端传id变量
    let id = req.body.id;

    //操作usersModel 删除方法
    UsersModel.findOneAndDelete({
        _id : id
    }).then((data)=>{
        if (data) {
            res.json({
                code : 0,
                msg : 'ok'
            }) 
        } else {
            return Promise.reject(new Error('未找到相关数据'))
            // res.json({
            //     code :-1,
            //     msg :'为找到相关数据'
            // })
        }
        
    }).catch(error =>{
        res.json({
            code : -1,
            msg : error.message
        })
    })
})

router.post('/searchOne',(req,res)=>{
    //通过id删除,得到要删除的id字段,前端传过来,post请求,前端传id变量
    let id = req.body.id;

    //操作usersModel 删除方法
    UsersModel.findById({
        _id : id
    }).then((data)=>{
        //console.log(data)
        if (data) {
            res.json({
                code : 0,
                msg : 'ok',
                data:data
            }) 
        } else {
            return Promise.reject(new Error('未找到相关数据'))
            // res.json({
            //     code :-1,
            //     msg :'为找到相关数据'
            // })
        }
        
    }).catch(error =>{
        res.json({
            code : -1,
            msg : error.message
        })
    })
})


router.post('/updateById',upload.single('usersImg'),(req,res)=>{
    console.log(req.file)
    //1.操作文件,把文件放在public下
    //console.log(req.body.usersName)
    //let newFileName = new Date().getTime() + '_' + req.file.originalname;
    //let newFilePath = path.resolve(__dirname,'../public/uploads/users/',newFileName);
    //console.log(newFilePath)
    //2.文件移动操作
    try {
        //文件的读写删除
        //let data = fs.readFileSync(req.file.path);
        
        //fs.writeFileSync(newFilePath,data);
        
        //fs.unlinkSync(req.file.path)
        
        //将文件名字 + users 图的名字写入到数据库
        UsersModel.updateOne({_id : req.body.id},{
            userName : req.body.userName,
            isAdmin : req.body.isAdmin,
            nickName : req.body.nickName,
            passWord : req.body.passWord,
        },function(error,docs){
            if (error) {
                console.log(req.body.id)
                res.json({
                    code : -1,
                    msg : error.message
                })
            } else {
                res.json({
                    code : 0,
                    msg : 'ok'
                })
                //console.log(docs)
            }
        })
    } catch (error) {
        res.json({
            code : -1,
            msg : error.message
        })
    }
})
module.exports = router;