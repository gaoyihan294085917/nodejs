const express = require('express');

const UserModel = require('../models/userModel');
const router = express.Router();

//定义注册接口地址 /user/register
router.post('/register', (req, res) => {
    //主要是把前端传过来的信息添加到数据库
    //1.得到数据,post请求req.body,如果前端传递过来的参数名跟表中的字段名相同
    //2.实例化用户对象
    // let user = new UserModel({
    //     userName : req.body.userName,
    //     passWord : req.body.passWord
    // })
    let user = new UserModel(req.body);
    //3.调用sava方法写入
    user.save().then(() => {
        //必须告诉前端,做结束请求的操作,要么是res.send,要么是res.json,不然请求会一直挂起
        res.json({
            code: 0,
            msg: '注册成功'
        })
    }).catch(error => {
        console.log(error.message)
        res.json({
            code: -1,
            msg: error.message
        })
    })
})

//定义登录接口地址 /user/login
router.post('/login', (req, res) => {
    //思路:前端传用户名密码过来,去找一下数据库对不对,对就登录成功,不对就失败
    //1.得到前端传递的用户名和密码
    let userName = req.body.userName;
    let passWord = req.body.passWord;
    //2.取数据库中查询用户,这个时候不要用UserModel.findOne(req.body)
    //因为前端可能不止传用户名和密码(比如isAdmin是0),它会把这几个条件当成一个并且去数据库里面找,这个时候就找不到具体的用户,但是实际上这个用户是存在的
    UserModel.findOne({
        userName,// userName: userName,
        passWord //passWord : passWord
    }).then(data => {
        //不管是否查找到都会在data里返回出来,如果找到了会返回一个对象,没找到会返回null
        console.log(data)//查找到的那个用户的字段信息
        if (!data) {//如果data不存在
            res.json({
                code: -1,
                msg: '用户名或密码错误'
            })
        } else {
            //先设置cookie
            res.cookie('nickName', data.nickName, {
                maxAge: 1000 * 60 * 10
            });
            res.cookie('isAdmin', data.isAdmin, {
                maxAge: 1000 * 60 * 10
            })


            //返回数据
            //登录成功后台只提供接口,不管成功之后是否跳其他页面
            //有需求是登录成功后可以把登录的信息,是否是管理员存下来,比如昵称要显示右上角,管理员相关权限,这个时候给前端带一些数据过去,放在data里
            res.json({
                code: 0,
                msg: '登录成功',
                data: {
                    id: data._id,//可以把数据库里的id传给前端
                    nickName: data.nickName,
                    isAdmin: data.isAdmin,
                    userName: data.userName
                }
            })
        }
    }).catch(error => {
        //这个catch表示如果代码出错才会走到这里,不是没找到用户
        res.json({
            code: -1,
            msg: error.message
        })
    })
})



module.exports = router;
