//1.自执行函数
(function(){
    var User = function(){
        //this.userName = '';如果这样写,还要监听input的change事件,input发生变化再把值写到这里来,有点麻烦
        //this.passWord = '';
        //可以直接用dom的val()
        this.btnLock = false;//登录按钮的锁
        this.dom = {
            submitBtn : $('#btn'),
            userNameInput : $('input[type=text]'),
            passWordInput : $('input[type=password]')
        }
    }
    /**
     * 3.绑定事件
     * 
     */
    User.prototype.bindDom = function(){
        var that = this;
        this.dom.submitBtn.click(function(){
            //发送ajax请求前先判断是否有锁
            if(!that.btnLock){
                //没锁的时候加把锁,并发送ajax请求
                that.btnLock = true;
                that.handleLogin();
            }
        })
    }

    /**
     * 2.登录方法,调取ajax
     */
    User.prototype.handleLogin = function(){
        var that = this;
        $.post('/user/login',{
            userName : this.dom.userNameInput.val(),
            passWord : this.dom.passWordInput.val()
        },function(res){
            if (res.code == 0) {
                //登录成功
                layer.msg('登录成功');
                //延时跳转,提高用户体验
                setTimeout(function(){
                    //跳转到首页
                    //window.location.href = 'http://localhost:3000/'
                    window.location.href = '/';
                }, 1000);
                
            } else {
                //登录失败
                layer.msg(res.msg);
            }
        })
        //不管是否登录成功都解锁
        that.btnLock = false;
    }

    //4.最后new出来,调用绑定事件
    //var user = new User();
    //user.bindDom()
    new User().bindDom()
})();