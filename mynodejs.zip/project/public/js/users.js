(function () {
    /**
     * 定义这个文件操作的构造函数
     */
    var Users = function () {
        //定义这个页面需要的一些数据
        this.pageNum = 1;//当前的页码数
        this.pageSize = 2;//每页显示多少条
        this.totalPage = 0;//总页数,是后台返回给前端的
        this.usersList = []//代表从后台取出来的那个Users数据
        this.id = 0;
        //需要用到的dom对象,提高性能,dom缓存
        this.dom = {
            table: $('#users-table tbody'), //table的tbody
            pagination: $('#pagination'), //分页的ul

            nickName: $('#nickName'), //新增的用户昵称
            isAdmin: $('#isAdmin'), //新增的是否管理员
            userName: $('#userName'), //新增的用户名
            passWord: $('#passWord'), //新增的密码
            addModal: $('#addModal'), //新增的模态框
            submitAdd: $('#usersAdd'), //确认新增的按钮

            nickName1: $('#nickName1'), //修改的用户昵称
            isAdmin1: $('#isAdmin1'), //修改的是否管理员
            userName1: $('#userName1'), //修改的用户名
            passWord1: $('#passWord1'), //修改的密码
            addModal1: $('#updateModal'), //修改的模态框
            usersUpdate: $('#usersUpdate1'), //确认修改的按钮
        }

        //新增的方法
        Users.prototype.add = function () {
            var that = this;
            //ajax带文件提交

            //1.实例化一个FormData对象
            var formData = new FormData();
            //2.给formData上加属性
            formData.append('nickName',this.dom.nickName.val());
            formData.append('isAdmin',this.dom.isAdmin.val());
            formData.append('userName',this.dom.userName.val());
            formData.append('passWord',this.dom.passWord.val());
            //formData.append('usersImg',this.dom.urlInput.val());
            //这里的this.dom.urlInput.val()拿不到文件对象,只能拿到文件的绝对路径
            //通过this.dom.urlInput[0]jquery转dom对象里的flies方法拿到input的type类型为file的文件对象,它是一个类数组,取第0个
            //formData.append('usersImg',this.dom.urlInput[0].files[0]);
            //如果用$.post有很多属性是设置不了的,所以要用$.ajax
            $.ajax({
                url : '/users/add',
                method : 'POST',
                contentType : false,//不让他使用默认的contentType
                processData : false,//文件上传需要设置这个属性
                data : formData,
                success : function(){
                    layer.msg('添加成功');
                    //请求下一条数据
                    that.search();
                },
                error : function(error){
                    console.log(error.message)
                    layer.msg('网络异常,请稍后重试')
                },
                complete : function(){
                    //不管成功或者失败,都会进入的一个回调函数
                    //手动关闭模态框
                    that.dom.addModal.modal('hide');
                    //that.search();
                    //手动清空输入框的内容
                    that.dom.nickName.val('');
                    that.dom.isAdmin.val('');
                    that.dom.userName.val('');
                    that.dom.passWord.val('');
                }
            })

        }

        //查询的方法
        Users.prototype.search = function(){
            var that = this;
            $.get('/users/search',{
                pageNum: this.pageNum,
                pageSize: this.pageSize
            }, function (result) {
                if (result.code === 0) {
                    layer.msg('查询成功');
                    console.log(result)
                    //将查询出来的结果result.data写入到实例的usersList里
                    that.usersList = result.data;
                    //将查询出来的结果result.totalPage写入到实例的totalPage里
                    that.totalPage = result.totalPage

                    //调用渲染table
                    that.randerTable();

                    //调用渲染分页
                    that.renderPage();
                } else {
                    console.log(result.msg)
                    layer.msg('网络异常,请稍后重试')
                }
            })
        }
        
        //删除的方法
        Users.prototype.delete = function(id){
            var that = this;
            $.post('/users/delete',{
                id : id
            },function(res){
                if (res.code === 0) {
                    layer.msg('删除成功')
                } else {
                    layer.msg('删除失败')
                }
            })
        }

        /**
         * 渲染table 从查询方法中提取出来
         */
        Users.prototype.randerTable = function(){
            this.dom.table.html('');
           
            for (var i = 0; i < this.usersList.length; i++) {
                var item = this.usersList[i];
                console.log(item.passWord)
                this.dom.table.append(
                    `
                    <tr>
                        <td data-id="${item.nickName}">${item.nickName}</td>
                        <td data-id="${item.isAdmin}">${item.isAdmin}</td>
                        <td data-id="${item.userName}">${item.userName}</td>
                        <td data-id="${item.passWord}">${item.passWord}</td>
                        <td>
                        <a class="delete" data-id="${item._id}" href="javascript:;">删除</a>
                        <a class="update" data-id="${item._id}" href="javascript:;" data-toggle="modal" data-target="#updateModal">修改</a>
                        </td>
                    </tr>
        
                    `
                )
            }
        }
        
        /**
         * 渲染分页
         */
        Users.prototype.renderPage = function(){
            this.dom.pagination.html('');
            //添加上一页
            this.dom.pagination.append(
                `
                <li data-num="${this.pageNum-1}">
                    <a href="#" aria-label="Previous">
                      <span aria-hidden="true">&laquo;</span>
                    </a>
                </li>

                `
            )
            //根据this.totalPage循环渲染多少个li
            for(var i = 0 ; i < this.totalPage ; i++){
                this.dom.pagination.append(
                    `
                    <li class="${this.pageNum === i+1 ? 'active' : ''}" data-num="${i+1}"><a href="#">${i+1}</a></li>
                    `
                )
            }

            //添加下一页
            this.dom.pagination.append(
                `
                <li data-num="${this.pageNum+1}">
                    <a href="#" aria-label="Next">
                      <span aria-hidden="true">&raquo;</span>
                    </a>
                </li>

                `
            )

        }


        //将所有dom事件的操作放在这里
        Users.prototype.bindDom = function(){
            var that = this;
            //点击确认按钮时前需要调用add方法
            this.dom.submitAdd.click(function(){
                that.add()
            })

            //分页按钮点击事件
            this.dom.pagination.on('click','li',function(){
                //1,得到页码
                //attr获取属性,如果是自定义属性并且用data-开头,我们可以更简单的使用data
                var num = parseInt($(this).data('num'));
                //判断点击的是不是相同页,或者<1,或者>总页数都要阻止一下
                if (num === that.pageNum || num < 1 || num > that.totalPage) {
                    return;
                } 
                //2.设置给 this.pagenum
                that.pageNum = num;
                //3.再次调用一下this.search,他会根据pageNum再次发送请求
                that.search();

            })

            //删除按钮点击
            this.dom.table.on('click','.delete',function(){
                //var that = this;
                //1.得到id
                var id = $(this).data('id');

                //2.二次确认框
                layer.confirm('确认删除吗',function(){
                    console.log(id)
                    that.delete(id);
                    setTimeout(function(){
                        that.pageNum = 1;
                        that.search();
                    }, 1000);
                    
                },function(){

                })
            })
            //修改按钮点击
            this.dom.table.on('click','.update',function(){
                //var that = this;
                //1.得到id
                that.id = $(this).data('id');
                //console.log( that.dom.nameInput.parent().parent().parent().parent().parent().parent().parent().parent())
                $.post('/users/searchOne',{
                    id : that.id
                },function(res){
                    if (res.code === 0) {
                        //console.log(res.data.name)
                        that.dom.nickName1[0].value = res.data.nickName
                        that.dom.isAdmin1[0].value = res.data.isAdmin
                        that.dom.userName1[0].value = res.data.userName
                        that.dom.passWord1[0].value = res.data.passWord
                        //that.dom.urlInput1[0].value = res.data.imgUrl
                        layer.msg('查询成功')
                    } else {
                        layer.msg('查询失败')
                    }
                })
                //console.log(id)
                //2.二次确认框
                
            })

            //确认修改按钮点击
            this.dom.usersUpdate.click(function(){
                //ajax带文件提交

                //1.实例化一个FormData对象
                var formData = new FormData();
                console.log(that.dom)
                //2.给formData上加属性
                formData.append('nickName',that.dom.nickName1.val());
                formData.append('isAdmin',that.dom.isAdmin1.val());
                formData.append('userName',that.dom.userName1.val());
                formData.append('passWord',that.dom.passWord1.val());
                console.log(that.dom.updateUrlInput)
                //formData.append('usersImg',this.dom.urlInput.val());
                //这里的this.dom.urlInput.val()拿不到文件对象,只能拿到文件的绝对路径
                //通过this.dom.urlInput[0]jquery转dom对象里的flies方法拿到input的type类型为file的文件对象,它是一个类数组,取第0个
                //formData.append('usersImg',that.dom.updateUrlInput[0].files[0]);
                formData.append('id',that.id);
                //如果用$.post有很多属性是设置不了的,所以要用$.ajax
                $.ajax({
                    url : '/users/updateById',
                    method : 'POST',
                    contentType : false,//不让他使用默认的contentType
                    processData : false,//文件上传需要设置这个属性
                    data : formData,
                    success : function(){
                        layer.msg('修改成功');
                        //请求下一条数据
                        that.search();
                    },
                    error : function(error){
                        console.log(error.message)
                        layer.msg('网络异常,请稍后重试')
                    },
                    complete : function(){
                        //不管成功或者失败,都会进入的一个回调函数
                        //手动关闭模态框
                        that.dom.addModal1.modal('hide');
                        //that.search();
                        //手动清空输入框的内容
                        that.dom.nickName.val('');
                        that.dom.isAdmin.val('');
                        that.dom.userName.val('');
                        that.dom.passWord.val('');
                    }
                })
            })
        }
    }


    //最后要实例化一下
    $(function(){
        var users = new Users();
        //绑定事件,让事件生效
        users.bindDom();
        //默认要渲染第一页,得到数据
        users.search();
    })
})();























// $(function(){
//     var pageNum = 1;
//     var pageSize = 3;

//     //默认调用一次search
//     search(pageNum,pageSize);



//     $('#usersAdd').click(function(){

//         $.post('/users/add',{
//             usersName: $('#inputEmail3').val(),
//             usersUrl:$('#inputPassword3').val()
//         },function(res){
//             console.log(res);
//             if (res.code === 0) {
//                 //成功
//                 layer.msg('添加成功')
//             } else {
//                 //失败.很多时候,真正的错误信息不回给用户去看
//                 //alert(res.msg)
//                 console.log(res.msg)
//                 alert('网络异常,请稍后重试')
//             }

//             //手动关闭模态框
//             $('#myModal').modal('hide');
//             //手动清空输入框的内容
//             $('#inputEmail3').val('');
//             $('#inputPassword3').val('')
//         })




//         //手动关闭模态框
//         //$('#myModal').modal('hide');
//     })


//     /**
//      * 查询users数据的方法,因为点击不同的页数要重复调取这个请求
//      * 
//      */
//     function search(pageNum,pageSize){
//         $.get('/users/search',{
//             pageNum:pageNum,
//             pageSize:pageSize
//         },function(result){
//             if (result.code === 0) {
//                 layer.msg('查询成功');
//                 for(var i=0; i < result.data.length; i++){
//                     var item = result.data[i];
//                     $('#users-table tbody').append(
//                         `
//                         <tr>
//                             <td>${item._id}</td>
//                             <td>${item.name}</td>
//                             <td>
//                                 <img src="${item.imgUrl}" alt="">
//                             </td>
//                             <td>
//                             <a href="javascript:;">删除</a>
//                             <a href="javascript:;">修改</a>
//                             </td>
//                         </tr>

//                         `
//                     )
//                 }


//             } else {
//                 console.log(result.msg)
//                 layer.msg('网络异常,请稍后重试')
//             }
//         })
//     }
// })