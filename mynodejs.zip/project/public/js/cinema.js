(function () {
    /**
     * 定义这个文件操作的构造函数
     */
    var Cinema = function () {
        //定义这个页面需要的一些数据
        this.pageNum = 1;//当前的页码数
        this.pageSize = 2;//每页显示多少条
        this.totalPage = 0;//总页数,是后台返回给前端的
        this.cinemaList = []//代表从后台取出来的那个banner数据
        this.id = 0;
        //需要用到的dom对象,提高性能,dom缓存
        this.dom = {
            table: $('#cinema-table tbody'), //table的tbody
            pagination: $('#pagination'), //分页的ul
            nameInput: $('#inputEmail3'), //新增的姓名输入框
            urlInput: $('#inputPassword3'), //url的输入框
            addModal: $('#addModal'), //新增的模态框
            submitAdd: $('#cinemaAdd'), //确认新增的按钮
            nameInput1 : $('#inputEmail4'),
            submitUpdate : $('#cinemaUpdate'),
            updateModal : $('#updateModal'),
            updateUrlInput : $('#inputPassword4')
        }

        //新增的方法
        Cinema.prototype.add = function () {
            var that = this;
            //ajax带文件提交

            //1.实例化一个FormData对象
            var formData = new FormData();
            //2.给formData上加属性
            formData.append('cinemaName',this.dom.nameInput.val());
            //formData.append('bannerImg',this.dom.urlInput.val());
            //这里的this.dom.urlInput.val()拿不到文件对象,只能拿到文件的绝对路径
            //通过this.dom.urlInput[0]jquery转dom对象里的flies方法拿到input的type类型为file的文件对象,它是一个类数组,取第0个
            formData.append('cinemaImg',this.dom.urlInput[0].files[0]);
            //如果用$.post有很多属性是设置不了的,所以要用$.ajax
            $.ajax({
                url : '/cinema/add',
                method : 'POST',
                contentType : false,//不让他使用默认的contentType
                processData : false,//文件上传需要设置这个属性
                data : formData,
                success : function(){
                    layer.msg('添加成功');
                    //请求下一条数据
                    that.search();
                },
                error : function(error){
                    console.log(error.message)
                    layer.msg('网络异常,请稍后重试')
                },
                complete : function(){
                    //不管成功或者失败,都会进入的一个回调函数
                    //手动关闭模态框
                    that.dom.addModal.modal('hide');
                    //that.search();
                    //手动清空输入框的内容
                    that.dom.nameInput.val('');
                    that.dom.urlInput.val('')
                }
            })


            
        }

        //查询的方法
        Cinema.prototype.search = function(){
            var that = this;
            $.get('/cinema/search',{
                pageNum: this.pageNum,
                pageSize: this.pageSize
            }, function (result) {
                if (result.code === 0) {
                    layer.msg('查询成功');
                    //将查询出来的结果result.data写入到实例的bannerList里
                    that.cinemaList = result.data;
                    //将查询出来的结果result.totalPage写入到实例的totalPage里
                    that.totalPage = result.totalPage

                    //调用渲染table
                    that.randerTable();

                    //调用渲染分页
                    that.renderPage();
                } else {
                    console.log(result.msg)
                    layer.msg('网络异常,请稍后重试')
                }
            })
        }
        
        //删除的方法
        Cinema.prototype.delete = function(id){
            var that = this;
            $.post('/cinema/delete',{
                id : id
            },function(res){
                if (res.code === 0) {
                    layer.msg('删除成功')
                } else {
                    layer.msg('删除失败')
                }
            })
        }

        /**
         * 渲染table 从查询方法中提取出来
         */
        Cinema.prototype.randerTable = function(){
            this.dom.table.html('');
            for (var i = 0; i < this.cinemaList.length; i++) {
                var item = this.cinemaList[i];
                this.dom.table.append(
                    `
                    <tr>
                        <td>${item._id}</td>
                        <td data-id="${item.name}">${item.name}</td>
                        <td data-id="${item.imgUrl}">
                            <img src="${item.imgUrl}" alt="">
                        </td>
                        <td>
                        <a class="delete" data-id="${item._id}" href="javascript:;">删除</a>
                        <a class="update" data-id="${item._id}" href="javascript:;" data-toggle="modal" data-target="#updateModal">修改</a>
                        </td>
                    </tr>
        
                    `
                )
            }
        }
        
        /**
         * 渲染分页
         */
        Cinema.prototype.renderPage = function(){
            this.dom.pagination.html('');
            //添加上一页
            this.dom.pagination.append(
                `
                <li data-num="${this.pageNum-1}">
                    <a href="#" aria-label="Previous">
                      <span aria-hidden="true">&laquo;</span>
                    </a>
                </li>

                `
            )
            //根据this.totalPage循环渲染多少个li
            for(var i = 0 ; i < this.totalPage ; i++){
                this.dom.pagination.append(
                    `
                    <li class="${this.pageNum === i+1 ? 'active' : ''}" data-num="${i+1}"><a href="#">${i+1}</a></li>
                    `
                )
            }

            //添加下一页
            this.dom.pagination.append(
                `
                <li data-num="${this.pageNum+1}">
                    <a href="#" aria-label="Next">
                      <span aria-hidden="true">&raquo;</span>
                    </a>
                </li>

                `
            )

        }


        //将所有dom事件的操作放在这里
        Cinema.prototype.bindDom = function(){
            var that = this;
            //点击确认按钮时前需要调用add方法
            this.dom.submitAdd.click(function(){
                that.add()
            })

            //分页按钮点击事件
            this.dom.pagination.on('click','li',function(){
                //1,得到页码
                //attr获取属性,如果是自定义属性并且用data-开头,我们可以更简单的使用data
                var num = parseInt($(this).data('num'));
                //判断点击的是不是相同页,或者<1,或者>总页数都要阻止一下
                if (num === that.pageNum || num < 1 || num > that.totalPage) {
                    return;
                } 
                //2.设置给 this.pagenum
                that.pageNum = num;
                //3.再次调用一下this.search,他会根据pageNum再次发送请求
                that.search();

            })

            //删除按钮点击
            this.dom.table.on('click','.delete',function(){
                //var that = this;
                //1.得到id
                var id = $(this).data('id');

                //2.二次确认框
                layer.confirm('确认删除吗',function(){
                    console.log(id)
                    that.delete(id);
                    setTimeout(function(){
                        that.pageNum = 1;
                        that.search();
                    }, 1000);
                    
                },function(){

                })
            })
            //修改按钮点击
            this.dom.table.on('click','.update',function(){
                //var that = this;
                //1.得到id
                that.id = $(this).data('id');
                //console.log( that.dom.nameInput.parent().parent().parent().parent().parent().parent().parent().parent())
                $.post('/cinema/searchOne',{
                    id : that.id
                },function(res){
                    if (res.code === 0) {
                        //console.log(res.data.name)
                        that.dom.nameInput1[0].value = res.data.name
                        //that.dom.urlInput1[0].value = res.data.imgUrl
                        layer.msg('查询成功')
                    } else {
                        layer.msg('查询失败')
                    }
                })
                //console.log(id)
                //2.二次确认框
                
            })

            //确认修改按钮点击
            this.dom.submitUpdate.click(function(){
                //ajax带文件提交

                //1.实例化一个FormData对象
                var formData = new FormData();
                //console.log(this.dom)
                //2.给formData上加属性
                formData.append('cinemaName',that.dom.nameInput1.val());
                console.log(that.dom.updateUrlInput)
                //formData.append('bannerImg',this.dom.urlInput.val());
                //这里的this.dom.urlInput.val()拿不到文件对象,只能拿到文件的绝对路径
                //通过this.dom.urlInput[0]jquery转dom对象里的flies方法拿到input的type类型为file的文件对象,它是一个类数组,取第0个
                formData.append('cinemaImg',that.dom.updateUrlInput[0].files[0]);
                formData.append('id',that.id);
                //如果用$.post有很多属性是设置不了的,所以要用$.ajax
                $.ajax({
                    url : '/cinema/updateById',
                    method : 'POST',
                    contentType : false,//不让他使用默认的contentType
                    processData : false,//文件上传需要设置这个属性
                    data : formData,
                    success : function(){
                        layer.msg('修改成功');
                        //请求下一条数据
                        that.search();
                    },
                    error : function(error){
                        console.log(error.message)
                        layer.msg('网络异常,请稍后重试')
                    },
                    complete : function(){
                        //不管成功或者失败,都会进入的一个回调函数
                        //手动关闭模态框
                        that.dom.updateModal.modal('hide');
                        //that.search();
                        //手动清空输入框的内容
                        that.dom.nameInput1.val('');
                        that.dom.urlInput.val('')
                    }
                })
            })
        }
    }


    //最后要实例化一下
    $(function(){
        var cinema = new Cinema();
        //绑定事件,让事件生效
        cinema.bindDom();
        //默认要渲染第一页,得到数据
        cinema.search();
    })
})();
















